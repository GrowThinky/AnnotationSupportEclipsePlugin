package javafoldingstructureprovider;

import org.eclipse.jface.text.Region;

public class InLineRegion extends Region {

	public InLineRegion(int offset, int length) {
		super(offset, length);
	}

}

package javafoldingstructureprovider;

import org.eclipse.jface.text.Region;

public class BlockRegion extends Region{

	public BlockRegion(int offset, int length) {
		super(offset, length);
	}

}

package annotationfoldingtestcases;

@Unfinished("Just articleware")
public @interface Unfinished {
  public enum Priority { LOW, MEDIUM, HIGH }

  String value();
  String[] owners() default "";
  Priority priority() default Priority.MEDIUM;
}
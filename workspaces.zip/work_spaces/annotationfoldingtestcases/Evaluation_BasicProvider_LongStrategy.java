/*******************************************************************************
 * Copyright (c) 2006, 2011 IBM Corporation and others.
 *
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License 2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package annotationfoldingtestcases;

public class Evaluation_BasicProvider_LongStrategy {
	

	public String name ;
	
	private String secret;
	
	@LongAnnotation(name = "happy_path",
		requires = { @requires("length > 0") },
		ensures =  { @ensures("length is old length minus 1") })
	public Store store;
	
	// Case 1
	
	@SuppressWarnings({"restriction","unused"})
	public Evaluation_BasicProvider_LongStrategy() {
		this.name = "fruit";
		this.secret = "bananas";
		store = new Store();
	}
	
	// Case 2	
	
		@LongAnnotation(name = "happy_path",
			 requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			 ensures = {
					@ensures("length is old length minus 1") })
		public String getSecret() {
			return secret;
		}

		// Case 3
		
		@LongAnnotation(name = "happy_path",
			requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
					@requires("new cardinality(elem) = old cardinality(elem) - 1"),
					@requires("returns true") },
			ensures = {
					@ensures("length is old length minus 1") })
		@SuppressWarnings({"restriction","unused"})
		public String getSecret3() {
			return secret;
		}
		
		// Case 4
		
		@SuppressWarnings({"restriction","unused"})
		@LongAnnotation(name = "happy_path",
			 requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			 ensures = {
					@ensures("length is old length minus 1") })
		public String getSecret2() {
			return secret;
		}
		
		// Case 5
		
		@LongAnnotation(name = "happy_path",
				requires = {
						@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
				ensures = {
						@ensures("length is old length minus 1") })
		@Pre("n > 10 && s != null")
		@Post("n > 10 && s != null")
		public String getName() {
			return this.name;
		}
		
		
		// Case 6
		
		@Pre("n > 10 && s != null")
		@Post("n = 10 && s != null")
		@LongAnnotation(name = "happy_path",   
				requires = { 
				@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
				@requires("new cardinality(elem) = old cardinality(elem) - 1"), // hello
				@requires("returns true") }, 
				ensures = { 
				@ensures("length is old length minus 1") })
		public void peeler3(Fruit fruit) {
			fruit.peel();
		}
		
		// Case 7
		
		@LongAnnotation(name = "happy_path",
			requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			ensures = {
					@ensures("length is old length minus 1") })
		@sub(name = "happy_path",
			requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
					@requires("new cardinality(elem) = old cardinality(elem) - 1"),
					@requires("returns true") },
			ensures = {
					@ensures("length is old length minus 1") })
		@Pre("n > 10 && s != null")
		public String getName3() {
			return this.name;
		}
		
		// Case 8 
		
			@LongAnnotation(name = "happy_path",
				requires = {
						@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
				ensures = {
						@ensures("length is old length minus 1") })
			@sub(name = "happy_path",
				requires = {
						@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
						@requires("new cardinality(elem) = old cardinality(elem) - 1"),
						@requires("returns true") },
				ensures = {
						@ensures("length is old length minus 1") })
			@Pre("n > 10 && s != null")
			@Post("n > 10 && s != null")
			public String getName4() {
				return this.name;
			}
		
		
		// Case 9
		
		@SuppressWarnings({"restriction","unused"})  // comment1
		@LongAnnotation(name = "happy_path",		// comment2
			 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			 ensures = {  @ensures("length is old length minus 1") })   // comment3
		public String getSecret5() {
			return secret;
		}
		

		
		
		// Case 10		/*	
		
		@LongAnnotation(name = "happy_path",		// comment2
			 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			 ensures = {  @ensures("length is old length minus 1") }) 
		// comment2
		@SuppressWarnings({"restriction","unused"})  // comment1// comment3 
		// comment3 
		public String getSecret6() {
			return secret;
		}
		
		
		
		// Actions		/
		

	
		@LongAnnotation(name = "happy_path",
		 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
		 ensures = {  @ensures("length is old length minus 1")}) 
		@SuppressWarnings({"restriction","unused"})
		public String getSecret7() {
			return secret;
		}
		
		
		public String getSecret8() {
			return secret;
		}
		

		
		
		
		
		
		
		
		
		
		
		
		
	}







package annotationfoldingtestcases;

public class Peach extends Fruit {
	
	public String name ;
	public Store store; 
	
	public Peach() {
		this.name = "peach";
		store = new Store();
	}

	
	public void juice2() {
		System.out.println("Peach Juice!");
	}
	
	@Override
	public String getName() {
		return this.name;
	}
	
	public void printSuper() {
		System.out.println(super.name);
	}
	
//	@Override
//	public void passToStore() {
//		store.toStore(this);	
//	}
	
	

}

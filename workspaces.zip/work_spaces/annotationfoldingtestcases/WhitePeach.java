package annotationfoldingtestcases;

public class WhitePeach extends Peach {
	
	@Override
	public void juice() {
		System.out.println("White Peach Juice!");
	}

}

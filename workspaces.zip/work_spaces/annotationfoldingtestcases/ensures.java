package annotationfoldingtestcases;

public @interface ensures {

	String value();

}

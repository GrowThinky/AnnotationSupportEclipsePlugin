package annotationfoldingtestcases;

public @interface Post {

	String value();

}

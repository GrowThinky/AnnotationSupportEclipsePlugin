package annotationfoldingtestcases;

public class Main {
	
	public static void main(String[] args) {
		
		Peach peach = new Peach();
//	
//		Store store = new Store();
//		
//		store.store(peach);
//		
		// Fruit f = new Fruit();
		
		//WhitePeach wPeach = new WhitePeach();
		
		peach.passToStore();
		peach.printSuper();
		
		System.out.println( peach.getSecret());
		

	}
	
	@SuppressWarnings({ "restriction","unused","restriction", "unused"  })/
	@Finished(value = "Class scope", priority = Unfinished.Priority.LOW)/
	@Unfinished(value = "Class scope", priority = Unfinished.Priority.LOW)/
	public void juice() {
		System.out.println("Fruit Juice!");
	}
	
	

}

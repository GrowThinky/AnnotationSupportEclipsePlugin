package annotationfoldingtestcases;

public @interface requires {

	String value();

}

package annotationfoldingtestcases;

public class FruitTest {
	
	
	@SuppressWarnings("unused")
	public void peel() {
		System.out.println("Fruit Peel!");
	}
}
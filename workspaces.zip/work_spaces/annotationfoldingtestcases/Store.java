package annotationfoldingtestcases;

public class Store {
	
	public void toStore(Fruit fruit) {
		System.out.println("Thanks! " + fruit.getName());
	}
	@SuppressWarnings("unused")
	public void toPrivateStore(Fruit fruit) {
		System.out.println("Thanks! (private) " +  fruit.getName());
	}

}

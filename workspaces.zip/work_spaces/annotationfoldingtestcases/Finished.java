package annotationfoldingtestcases;

import annotationfoldingtestcases.Unfinished.Priority;

public @interface Finished {

	String value();

	Priority priority();

}

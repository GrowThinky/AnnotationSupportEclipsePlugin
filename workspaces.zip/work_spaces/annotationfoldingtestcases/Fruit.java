
package annotationfoldingtestcases;

import java.lang.annotation.Documented;
import java.lang.annotation.Target;

public class Fruit {
	
	public String name ;
	
	private String secret;
	
	public Store store;

	
	/**
	 * A context that contains the information needed to compute the folding structure of an
	 * {@link ICompilationUnit} or an {@link IClassFile}. Computed folding regions are collected
	 * via
	 * {@linkplain #addProjectionRange(DefaultJavaFoldingStructureProvider.JavaProjectionAnnotation, Position) addProjectionRange}.
	 */
	@SuppressWarnings({"restriction","unused"})
	public Fruit() {
		this.name = "fruit";
		this.secret = "bananas";
		store = new Store();
	}

	
	@SuppressWarnings({ "restriction","unused","restriction", "unused"  })
	@Finished(value = "Class scope", priority = Unfinished.Priority.LOW)
	@Unfinished(value = "Class scope", priority = Unfinished.Priority.LOW)
	public void methodName() {
		System.out.println("Hello World!");
	}
	
	
	@SuppressWarnings({ "restriction","unused","restriction", "unused"  })
	@Unfinished(value = "Class scope", priority = Unfinished.Priority.LOW)
	public void juice2() {
		System.out.println("Fruit Juice!");
	}

	
	@SuppressWarnings("unused")
	public void peel() {
		System.out.println("Fruit Peel!");
	}
	
	@SuppressWarnings("unused")
	protected void eat() {
		System.out.println("Fruit Eat!");
	}
	

	

	@sub (name = "happy_path",
			requires = { 
			@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
			@requires("new cardinality(elem) = old cardinality(elem) - 1"),
			@requires("returns true") }, 
			ensures = { 
			@ensures("length is old length minus 1") })
	@Pre ("n > 10 && s != null")
	@Post("n = 10 && s != null")
	public void peeler2(Fruit fruit) {
		fruit.peel();
	}
	
	@Pre("n > 10 && s != null")
	@Post("n > 10 && s != null")
	public String getName() {
		return this.name;
	}
	
	public void passToStore() {
		store.toStore(this);
		passToPrivateStore();
	}
	
	private void passToPrivateStore() {
		store.toPrivateStore(this);
	}
	
	
	//@sub ... name="happy_path" ...
	
	
	@sub( 
			name = "happy_path",   
			requires = { 
			@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
			@requires("new cardinality(elem) = old cardinality(elem) - 1"),
			@requires("returns true") }, 
			ensures = {   
			@ensures("length is old length minus 1") })
	public String getSecret() {
		return secret;
	}
	

	@sub(name = "happy_path",   
			requires = { 
			@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
			@requires("new cardinality(elem) = old cardinality(elem) - 1"), // hello
			@requires("returns true") }, 
			ensures = { 
			@ensures("length is old length minus 1") })
	@Pre("n > 10 && s != null")
	@Post("n = 10 && s != null")
	public void peeler3(Fruit fruit) {
		fruit.peel();
	}
	

	@sub(name = "happy_path",
			requires = { 
			@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
			@requires("new cardinality(elem) = old cardinality(elem) - 1"),
			@requires("returns true") }, 
			ensures = {   
			@ensures("length is old length minus 1") })
	@Pre("n > 10 && s != null")
	@Post("n > 10 && s != null")
	public String getSecret33() {
		int one = 1;
		return secret;
	}
	

	@Pre("n > 10 && s != null")
	@Post("n > 10 && s != null")
	public String niceMethod2() {
		int one = 1;
		return secret;
	}


}





package annotationfoldingtestcases;

public class Evaluation_BasicProvider_SingleRangeStrategy {
	
	public String name ;
	
	private String secret;
	
	@LongAnnotation(name = "happy_path",
			requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			ensures = {
					@ensures("length is old length minus 1") })
	public Store store;
	
	
	// Case 1:
	
	@SuppressWarnings({"restriction","unused"})
	public Evaluation_BasicProvider_SingleRangeStrategy() {
		this.name = "fruit";
		this.secret = "bananas";
		store = new Store();
	}
	
	
	// Case 2	
	
	@LongAnnotation(name = "happy_path",
		 requires = {
				@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
		 ensures = {
				@ensures("length is old length minus 1") })	
	public String getSecret() {
		return secret;
	}

	// Case 3
	
	@LongAnnotation( name = "happy_path", 
			requires = { 
			@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
			@requires("new cardinality(elem) = old cardinality(elem) - 1"),
			@requires("returns true") }, 
			ensures = {   
			@ensures("length is old length minus 1") }) 
	@SuppressWarnings({"restriction","unused"})
	public String getSecret3() {
		return secret;
	}
	
	// Case 4
	
	@SuppressWarnings({"restriction","unused"})
	@LongAnnotation(name = "happy_path",
		 requires = {
				@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
		 ensures = {
				@ensures("length is old length minus 1") })
	public String getSecret2() {
		return secret;
	}
	
	// Case 5
	
	@LongAnnotation(name = "happy_path",
			requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			ensures = {
					@ensures("length is old length minus 1") })
	@Pre("n > 10 && s != null")
	@Post("n > 10 && s != null")
	public String getName() {
		return this.name;
	}
	
	
	// Case 6
	
	@Pre("n > 10 && s != null")
	@Post("n = 10 && s != null")
	@LongAnnotation(
			name = "happy_path",   
			requires = { 
			@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
			@requires("new cardinality(elem) = old cardinality(elem) - 1"), // hello
			@requires("returns true") }, 
			ensures = { 
			@ensures("length is old length minus 1") })
	public void peeler3(Fruit fruit) {
		fruit.peel();
	}
	
	// Case 7
	
	@LongAnnotation(name = "happy_path",
		requires = {
				@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
		ensures = {
				@ensures("length is old length minus 1") })
	@sub(name = "happy_path",
		requires = {
				@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
				@requires("new cardinality(elem) = old cardinality(elem) - 1"),
				@requires("returns true") },
		ensures = {
				@ensures("length is old length minus 1") })
	@Pre("n > 10 && s != null")
	public String getName3() {
		return this.name;
	}
	
	// Case 8 
	
		@LongAnnotation(name = "happy_path",
			requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0") },
			ensures = {
					@ensures("length is old length minus 1") })
		@sub(name = "happy_path",
			requires = {
					@requires("length > 0 and the bag contains n elements of elem, with n > 0"),
					@requires("new cardinality(elem) = old cardinality(elem) - 1"),
					@requires("returns true") },
			ensures = {
					@ensures("length is old length minus 1") })
		@Pre("n > 10 && s != null")
		@Post("n > 10 && s != null")
		public String getName4() {
			return this.name;
		}
	
	
	// Case 9
	
	@SuppressWarnings({"restriction","unused"})  // comment1
	@LongAnnotation(name = "happy_path",		// comment2
		 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
		 ensures = {  @ensures("length is old length minus 1") })   // comment3
	public String getSecret5() {
		return secret;
	}
	
	
	// Case 10
	
	@LongAnnotation(name = "happy_path",
		 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
		 ensures = {  @ensures("length is old length minus 1") })   
	// comment1
	@Pre("n > 10 && s != null")
	// comment1
	@Post("n > 10 && s != null")
	public String getSecret6() {
		return secret;
	}
	
	
	// Case 11
	
//	@SuppressWarnings({"restriction","unused"})  // comment1
//	@LongAnnotation(name = "happy_path",		
//	 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
//	 ensures = {  @ensures("length is old length minus 1") })
//	pubic hello() {
//		
//	}
	
	
	// Case 12
	
//	@SuppressWarnings({"restriction","unused"})  // comment1
//	@LongAnnotation(name "happy_path",		
//	 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
//	 ensures = {  @ensures("length is old length minus 1"
//	public void hello() {
//		
//	}
	
	
	
	
	// Case 12
	
	@SuppressWarnings({"restriction","unused"})  // comment1
	
	@LongAnnotation(name = "happy_path",		
	 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
	 ensures = {  @ensures("length is old length minus 1") })
	public void hello2() {
		
	}
	
	
	
	// Case 13
	
	@SuppressWarnings({"restriction","unused"})  // comment1
	@LongAnnotation(name = "happy_path",		
	 requires = { @requires("length > 0 and the bag contains n elements of elem, with n > 0") },
	 ensures = {  @ensures("length is old length minus 1") })
	
	public void hello3() {
		
	}
	
	

	

	
	
	
	
	
	
	
	
	
	
	
	
}



 @interface LongAnnotation {
	
	String name() default "";

	requires[] requires();

	ensures[] ensures();
	
	

}


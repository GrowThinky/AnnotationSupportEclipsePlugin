package annotationfoldingtestcases;

public @interface sub {
	
	String name() default "";

	requires[] requires();

	ensures[] ensures();
	
	

}

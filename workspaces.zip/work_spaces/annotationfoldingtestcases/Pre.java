package annotationfoldingtestcases;

public @interface Pre {

	String value();

}
